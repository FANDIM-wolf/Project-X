<html>
<head>
    
</head>
<body>


  <h2>{{$value['title']}}</h2>
  <br>
  <p>{{$value['description']}}</p>
  <br>
  <h2>{{$value['created_at']}}</h2>
  <br>
 @foreach($value->comment as $value->comment)
   
   {{$value->comment->content_of_comment}}

 @endforeach 
  <form  method="post" action="/post/{{ $value['id'] }}/comment">
  @csrf()
  <textarea name="content_of_comment">
  </textarea>
  <input type="submit">
  </form>
</body>
</html>