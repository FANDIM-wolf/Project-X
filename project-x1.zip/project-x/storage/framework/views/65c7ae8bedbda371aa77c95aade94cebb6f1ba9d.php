<html>
<head>
    
</head>
<body>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="/post/<?php echo e($post['id']); ?>"><?php echo e($post['title']); ?></a>
  <br>
  <h2><?php echo e($post['created_at']); ?></h2>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<form action="/registration" method="get">
    <input type="text" name="name">
    <input type="text" name="email">
    <input type="text" name="password">
    <input type="text" name="password_check">
    <input type="submit">
</form>
</body>
</html><?php /**PATH D:\project-x\project-x\resources\views/main.blade.php ENDPATH**/ ?>