<html>
<head>
    
</head>
<body>


  <h2><?php echo e($value['title']); ?></h2>
  <br>
  <p><?php echo e($value['description']); ?></p>
  <br>
  <h2><?php echo e($value['created_at']); ?></h2>
  <br>


</body>
</html><?php /**PATH D:\project-x\project-x\resources\views/post.blade.php ENDPATH**/ ?>