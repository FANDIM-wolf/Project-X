<html>
<head>
    
</head>
<body>


  <h2>{{$value['title']}}</h2>
  <br>
  <p>{{$value['description']}}</p>
  <br>
  <h2>{{$value['created_at']}}</h2>
  <br>


</body>
</html>