<html>
<head>
    
</head>
<body>
<a href="/weather">Погода</a>
<a href="/sport">Спорт</a>
<a href="/news">Новости</a>
<a href="/hot_news">Топ</a>
<br>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="/post/<?php echo e($post['id']); ?>"><?php echo e($post['title']); ?></a>
  <br>
  <h2><?php echo e($post['created_at']); ?></h2>
  <br>
  <img src="/images/<?php echo e($post['image']); ?>" width="450" height="500">
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<form action="/registration" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <input type="text" name="name">
    <input type="text" name="email">
    <input type="text" name="password">
    <br>
    <input type="text" name="password_check">
    <br>
    <input type="file" name="image">
    <br>
    <input type="submit">

</form>



</body>
</html><?php /**PATH D:\project-x\project-x\resources\views/main.blade.php ENDPATH**/ ?>