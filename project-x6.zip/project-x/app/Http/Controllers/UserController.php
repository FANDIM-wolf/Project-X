<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\post;
use App\Models\comment;
use App\Models\User_site;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    //
    //get registration view 
    public function get_registration_view(Request $request){

        return view('reg');
    }


    //get request and check email for exist
    public function registration(Request $request){
        $this->validate($request, [
            'name' => 'required|max:255',
            'password' => 'required|min:8',
            'email'=>'required|email'
        ]);
        //init new object
     
        $user=new User_site;
        $password_check =$request->input("password_check");
        $posts = post::all();
        $user->fill([
        'name' =>$request->name,
        'email'=>$request->email,
        'password'=>$request->password,
        ]);
        
        $image = $request->file('image');
        $imageName = time().'.'.$image->extension();
        $image->move(public_path('images'),$imageName);

        $user->image=$imageName;
     
        //get all users to check for exist
         
        $users = User_site::all();
        foreach($users as $value ){
           if ($value->name ==$user->name ){
               if($value->password == $user->password){
                   if($value->email ==$user->email){
                       
                       return redirect('/'); //go home

                   }
               }
           }
        }
        if($user->password == $password_check ){
           $user->save();
        }
        // return view('main',['posts'=>$posts]);
        return redirect('/'); //go home
        }
}
