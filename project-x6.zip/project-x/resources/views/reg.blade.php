<html>
<head>
    
</head>
<body>



<form action="/registration" method="post" enctype="multipart/form-data">
@csrf()
    <input type="text" name="name">
    <input type="text" name="email">
    <input type="text" name="password">
    <br>
    <input type="text" name="password_check">
    <br>
    <input type="file" name="image">
    <br>
    <input type="submit">

</form>



</body>
</html>