<html>
<head>
    
</head>
<body>



<?php $__currentLoopData = $weather; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weather): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="/post/<?php echo e($post['id']); ?>"><?php echo e($weather['title']); ?></a>
  <br>
  <h2><?php echo e($weather['created_at']); ?></h2>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH D:\project-x\project-x\resources\views/weather.blade.php ENDPATH**/ ?>