<html>
<head>
    
</head>
<body>


  <h2><?php echo e($value['title']); ?></h2>
  <br>
  <p><?php echo e($value['description']); ?></p>
  <br>
  <h2><?php echo e($value['created_at']); ?></h2>
  <br>
 <?php $__currentLoopData = $value->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value->comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
   <?php echo e($value->comment->content_of_comment); ?>


 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  <form  method="post" action="/post/<?php echo e($value['id']); ?>/comment">
  <?php echo csrf_field(); ?>
  <textarea name="content_of_comment">
  </textarea>
  <input type="submit">
  </form>
</body>
</html><?php /**PATH D:\project-x\project-x\resources\views/post.blade.php ENDPATH**/ ?>